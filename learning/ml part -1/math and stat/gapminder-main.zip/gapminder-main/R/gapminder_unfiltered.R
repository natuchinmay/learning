#' Gapminder data, unfiltered.
#' 
#' The supplemental data frame \code{gapminder_unfiltered} was not filtered on 
#' \code{year} or for complete data and has 3313 rows. Everything else is as
#' documented in \code{\link{gapminder}}.
"gapminder_unfiltered"
