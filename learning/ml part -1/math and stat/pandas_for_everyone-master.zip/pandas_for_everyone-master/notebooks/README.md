# Notebooks

This folder can be used to put your Jupyter Notebooks or scripts as you follow along with the book.
