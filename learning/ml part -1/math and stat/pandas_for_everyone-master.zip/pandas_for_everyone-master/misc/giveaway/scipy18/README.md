# SciPy 2018

### Thank you SciPy for being such a great community.

I've put a google form for people to sign up for the Raffle:

https://goo.gl/forms/m4ioDOzAgxWAGPgR2

I'll draw the winners at the end of the day :)
