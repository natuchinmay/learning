Notebooks used to do live teachings
