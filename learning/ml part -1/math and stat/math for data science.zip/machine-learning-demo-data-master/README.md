# Machine Learning Demo Data

Where I store data for different machine learning examples
